# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archery_secret']

package_data = \
{'': ['*']}

install_requires = \
['argon2-cffi>=20.1.0,<21.0.0',
 'cryptography>=3.4.7,<4.0.0',
 'python-dotenv>=0.17.0,<0.18.0']

setup_kwargs = {
    'name': 'archery-secret',
    'version': '0.1.0',
    'description': 'Generates, encrypt, decrypt and verify secrets.',
    'long_description': "# Archery Secret\n\nGenerates, encrypt, decrypt and verify secrets.\n\n[Github](https://github.com/archeryhq/archery-secret)\n\n[Pipy](https://pypi.org/project/archery-secret/)\n\n## How to use\n\nBefore using the module, it is necessary to create an environment variable *ARCHERY_PERSON_SECRET*, which can be inside an .env file inside the project.This key must be 32 url-safe base64-encoded bytes.\n\n```python\n>>> from archery_secret import Secret\n>>>\n>>>\n>>> passphrase = 'My_most_hidden_secret'\n>>> secret = Secret()\n>>> secret.randomic\n'etH-rDnCiroCDVt4TzgWl99cJV1jLQVt-JrBOAEmzbA='\n>>> encrypt = secret.encrypt(passphrase)\n>>> encrypt\n'gAAAAABgbNDuhZqY16KlnXbl6X_F5PO0PgA2ExpSfTmw9szmzpR2FO1qz1YUE9rU84DU1q9jRszApSk58Vgvo5UVZwKgsFzvRgWHxI6YLuFNOVcsM2v0sQ8='\n>>> secret.decrypt(encrypt)\n'My_most_hidden_secret'\n>>> hash = secret.generate(passphrase)\n>>> hash\n'$argon2id$v=19$m=102400,t=2,p=8$DxKq0YC4ICc6x6gsn5L6DA$2gFfRH6lYqIaI01nAwKcMQ'\n>>> secret.verify(hash, passphrase)\nTrue\n```",
    'author': 'eniocsj',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/archeryhq/archery-secret',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
